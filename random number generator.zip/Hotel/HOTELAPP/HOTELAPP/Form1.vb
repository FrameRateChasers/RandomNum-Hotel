﻿Public Class Form1


    'jeffrey hagan
    'vb for business

    Const Max_NumFloors As Integer = 7                  ' 8 elements = 8 floors
    Dim intOccupancyArray(Max_NumFloors) As Integer          ' Occupancy count array
    Const int_Hold_Subscribt As Integer = 1

    Const MAX_FLOOR_NUM As Integer = 8
    Const ROOMS_PER_FLOOR_NUM As Integer = 30
    Dim intOccupancySum As Integer   ' Total Occupancy count 
    Dim intOccupancyNum As Integer
    Dim inthold4 As Double
    Dim intHoldVar(int_Hold_Subscribt) As Integer



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnSave.Click


        If Not Integer.TryParse(txtOccupancy.Text, intOccupancyNum) Or txtOccupancy.Text = String.Empty Then
            MsgBox("please do not leave occupany empty, please enter number")
        ElseIf intOccupancyNum > 30 Then
            txtOccupancy.Text = ""
            MsgBox("please enter a occupancy less than or equal to 30")
        Else
            Calculation()
            If lstBox1.Items.Count = 8 Then
                TotalOCC()
                ResetInput()
            End If
        End If



    End Sub


    Private Sub TotalOCC()
        inthold4 = (intOccupancySum / (MAX_FLOOR_NUM * ROOMS_PER_FLOOR_NUM))
        lblOccupancyRateSum.Text = inthold4.ToString("p")
        lblTotalOutput.Text = intOccupancySum
    End Sub
    Private Sub Calculation()

        intHoldVar(0) = cboFloors.SelectedIndex
        intHoldVar(1) = intHoldVar(0) + 1
        lstBox1.Items.Add("Floor Number: " & intHoldVar(1) & " Rooms Occupied: " & comboSub(intHoldVar(0)) & " Occupancy Rate: " & (intOccupancyNum / ROOMS_PER_FLOOR_NUM) * 100 & "%")

        If cboFloors.SelectedIndex < (cboFloors.Items.Count - 1) Then
            cboFloors.SelectedIndex = cboFloors.SelectedIndex + 1
        ElseIf cboFloors.SelectedIndex = 7 Then
            cboFloors.Text = ""
        End If


    End Sub




    Private Function comboSub(ByVal arraryNum As Integer)
        intOccupancyArray(arraryNum) = Integer.TryParse(txtOccupancy.Text, intOccupancyNum)
        intOccupancySum += intOccupancyNum
        Return intOccupancyNum
    End Function

    Private Sub ResetInput()
        MsgBox("you have reached end. Please take a look at results list will be reset once you press ok")
        lstBox1.Items.Clear()
        txtOccupancy.Text = ""
        cboFloors.SelectedIndex = -1
        lblOccupancyRateSum.Text = ""
        lblTotalOutput.Text = ""
        intOccupancySum = 0
    End Sub
    Private Sub btnRestart_Click(sender As Object, e As EventArgs) Handles btnRestart.Click
        lblOccupancyRateSum.Text = ""
        lblTotalOutput.Text = ""
        cboFloors.Text = ""
        txtOccupancy.Text = ""
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
