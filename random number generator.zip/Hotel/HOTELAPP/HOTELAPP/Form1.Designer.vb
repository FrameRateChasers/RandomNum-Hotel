﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRestart = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOccupancy = New System.Windows.Forms.TextBox()
        Me.cboFloors = New System.Windows.Forms.ComboBox()
        Me.lstBox1 = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblOccupancyRateSum = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotalOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnRestart
        '
        Me.btnRestart.Location = New System.Drawing.Point(72, 386)
        Me.btnRestart.Name = "btnRestart"
        Me.btnRestart.Size = New System.Drawing.Size(166, 68)
        Me.btnRestart.TabIndex = 0
        Me.btnRestart.Text = "restart"
        Me.btnRestart.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(254, 386)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(166, 68)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(335, 40)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(121, 44)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(25, 12)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(454, 121)
        Me.Button5.TabIndex = 4
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Select the floor:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(175, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "number of occupied rooms"
        '
        'txtOccupancy
        '
        Me.txtOccupancy.Location = New System.Drawing.Point(178, 63)
        Me.txtOccupancy.Name = "txtOccupancy"
        Me.txtOccupancy.Size = New System.Drawing.Size(100, 20)
        Me.txtOccupancy.TabIndex = 9
        '
        'cboFloors
        '
        Me.cboFloors.FormattingEnabled = True
        Me.cboFloors.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8"})
        Me.cboFloors.Location = New System.Drawing.Point(40, 63)
        Me.cboFloors.Name = "cboFloors"
        Me.cboFloors.Size = New System.Drawing.Size(121, 21)
        Me.cboFloors.TabIndex = 10
        Me.cboFloors.Text = "Select a floor"
        '
        'lstBox1
        '
        Me.lstBox1.FormattingEnabled = True
        Me.lstBox1.Location = New System.Drawing.Point(25, 166)
        Me.lstBox1.Name = "lstBox1"
        Me.lstBox1.Size = New System.Drawing.Size(454, 147)
        Me.lstBox1.TabIndex = 11
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 326)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Total rooms occupied "
        '
        'lblOccupancyRateSum
        '
        Me.lblOccupancyRateSum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOccupancyRateSum.Location = New System.Drawing.Point(373, 323)
        Me.lblOccupancyRateSum.Name = "lblOccupancyRateSum"
        Me.lblOccupancyRateSum.Size = New System.Drawing.Size(115, 28)
        Me.lblOccupancyRateSum.TabIndex = 14
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(252, 326)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(115, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "overall occupancy rate"
        '
        'lblTotalOutput
        '
        Me.lblTotalOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalOutput.Location = New System.Drawing.Point(123, 326)
        Me.lblTotalOutput.Name = "lblTotalOutput"
        Me.lblTotalOutput.Size = New System.Drawing.Size(115, 26)
        Me.lblTotalOutput.TabIndex = 16
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(518, 466)
        Me.Controls.Add(Me.lblTotalOutput)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblOccupancyRateSum)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lstBox1)
        Me.Controls.Add(Me.cboFloors)
        Me.Controls.Add(Me.txtOccupancy)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnRestart)
        Me.Controls.Add(Me.Button5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnRestart As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtOccupancy As TextBox
    Friend WithEvents cboFloors As ComboBox
    Friend WithEvents lstBox1 As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblOccupancyRateSum As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotalOutput As Label
End Class
