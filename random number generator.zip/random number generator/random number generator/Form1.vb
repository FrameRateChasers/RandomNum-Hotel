﻿Public Class Form1

    Dim rand As New Random()
    Dim intSubScript As Integer = 5
    Dim intArrayNums(intSubScript) As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click





        arraySub()

        lblOutput.Text = intArrayNums(0) & "   " & "," & intArrayNums(1) & "   " & "," & intArrayNums(2) & "   " & "," & intArrayNums(3) & "   " & "," & intArrayNums(4) & "   " & "," & intArrayNums(5)

        lblMedian.Text = (intArrayNums(3) + intArrayNums(4)) / 2

    End Sub


    Private Sub arraySub()

        For counter = 0 To intSubScript
            intArrayNums(counter) = rand.Next(100)
        Next
        Array.Sort(intArrayNums)
    End Sub


End Class
